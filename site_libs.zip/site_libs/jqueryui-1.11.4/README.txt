This a jQuery UI custom build, downloaded from:
http://jqueryui.com/download/#!version=1.11.4&components=1111111111110111111111111111111111111

It includes all components except the datepicker, because it conflicts with
bootstrap-datepicker that is packaged with Shiny.

The copy of jQuery that is bundled with the download, under external/, is not
included because Shiny already has its own copy of jQuery.
